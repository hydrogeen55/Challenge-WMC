<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    $mail = new PHPMailer(true);

    try {
        // SMTP-Einstellungen (ersetze sie durch deine eigenen)
        $mail->isSMTP();
        $mail->Host = 'smtp-relay.brevo.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'privat.arda@gmail.com';
        $mail->Password = '3HcPtTxQUVJRE2gm';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Absender und Empfänger
        $mail->setFrom($email);
        $mail->addAddress('privat.arda@gmail.com');

        // E-Mail-Inhalt
        $mail->isHTML(true);
        $mail->Subject = 'Neue Anfrage aus der Travelseite';
        $mail->Body = "Name: $name<br>E-Mail: $email<br>Telefonnummer: $phone<br>Nachricht: $message";

        $mail->send();
        header("Location: index.html?mailsend=success");
    } catch (Exception $e) {
        echo "Fehler beim Senden der E-Mail: {$mail->ErrorInfo}";
    }
}
?>
